# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 03/02/2022
# Last Modified: 

#Purpose of script : Tutorial: Common Econometrics 

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
# make sure to install whichever packages you don't already have! 
library(here)
library(tidyverse)
library(modelr)
library(lfe) # an option for fixed effects 
library(AER) # companion package to  "Applied Econometrics with R"
library(stargazer) # for nice regression tables 

# 
options(scipen = 999)

# import data ####
data(Fatalities)
# Data Dictionary: https://rdrr.io/cran/AER/man/Fatalities.html
Fatalities <- 
   Fatalities %>% # fatalities data from AER package 
    mutate(fatal_rate = fatal/(pop/1000))

# simple regression model ####
# linear model, one explanatory var 
simple_model <- lm(fatal_rate ~ beertax, 
                   data = Fatalities)
summary(simple_model)

# alternative to summary: return a table with values with broom::tidy() & glance() 
regression_output_table <- 
  broom::tidy(simple_model)

regression_fit_stats <- 
  broom::glance(simple_model)

# just to show you how to scale things & generate multiple models 
#with this simple example model & the broom package
nested_data <- 
  Fatalities %>% 
  group_by(state) %>% 
  nest()
# nesting data can be useful sometimes - basically just allows you 
# to save a matrix within your table 
state_model <- function(df) {
  lm(fatal_rate ~ beertax, data = df)
}

# remember the purrr package from my data manipulation session? 
# its still our friend here: 
state_data_with_output <-
  nested_data %>% 
  mutate(model = map(data, state_model),
         model_output = map(model, broom::tidy),
         model_stats = map(model, broom::glance))


streamline_multi_model_output <- 
  state_data_with_output %>% 
  select(
    state, 
    model_output,
    model_stats
  ) %>% 
  unnest(cols = c(model_output, model_stats)) 
# uh oh an error! we have duplicated variable names 
# lets look at the documentation for unnest 
?unnest()
# ok we'll use names_repair = "universal"
streamline_multi_model_output <- 
  state_data_with_output %>% 
  select(
    state, 
    model_output,
    model_stats
  ) %>% 
  unnest(cols = c(model_output, model_stats),
         names_repair = "universal")

# I dont do a lot of nesting in my own work 
# but its ocassionally useful, 
# which is why we went through this example

# alt approach, without nesting: 
gen_state_models <- function(state_abbr_input) {
  filt_data <- 
    Fatalities %>% 
    filter(state == state_abbr_input)
  
  model <- 
    lm(fatal_rate ~ beertax, data = filt_data)
  
  # get output table 
  
  broom::tidy(model) %>% 
    mutate(state = state_abbr_input)
}
# alternate version of the same function 
gen_state_models_v2 <- function(state_abbr_input) {
  model <- 
    lm(fatal_rate ~ beertax,
       data =  (Fatalities %>% 
            filter(state == state_abbr_input)))
  
  # get output table 
  broom::tidy(model) %>% 
    mutate(state = state_abbr_input)
}


# test 

gen_state_models('al')
gen_state_models_v2('al')
# all at once: 
# map_dfr - dataframe output, wil row_bind all indiv. output tables 
all_models <- map_dfr(unique(Fatalities$state), 
                      gen_state_models)

# anyways! back to a single model at a time 

# usually we want robust std. errors: 
# in stata this is simple 'regress y x, robust' 
# less easy in r, although google will tell you to use: 
# summary(simple_model, robust = T)
# this actually doesnt work - despite documentation saying it should 
# believe me - I've tested it and been consistently disappointed

# vcovHC - gives you options for how to get robust SE 
# HC0 is White's origingal estimator 
# default type is is HC3 
# the documenation for this function cites the study
# which recommends this if you'd like to learn more 
cov_test  <- vcovHC(simple_model,
                    type = "HC3")

robust_se_test    <- sqrt(diag(cov_test))

robust_se_test

# add clustered SEs 
clustered_ses <- coeftest(simple_model, 
                          vcov = vcovCL,
                          cluster = ~state)
clustered_ses

# comparison with original: 
summary(simple_model)
# they are in fact different 

# this is not a causal analysis, just an example 
# if beer taxes do increase traffic fatalities - we should abolish beer taxes 

# generate predicted values ####
# base R: version 
# this produces a vector with all values 
pred <- predict(simple_model)
# add in a graph w/ regression line 
# this is done sequentially with the original data frame - so the first entry 
# is the prediction for the first row 
data_with_predictions_1 <- 
  Fatalities %>% 
  cbind(pred) %>% 
  mutate(residuals = pred - fatal_rate)

# tidyverse - modelr 
data_with_predictions_2 <-
  Fatalities %>% 
  add_predictions(simple_model)  %>% 
  mutate(residuals = pred - fatal_rate)


identical(data_with_predictions_1, data_with_predictions_2)

# statistics on residuals 
summary(data_with_predictions_2$residuals)
# mean is zero - this is by construction in OLS, but still good to see the distribution 

# make residuals graph 

data_with_predictions_2 %>% 
  ggplot(aes(x = beertax,
             y = residuals,
             color = residuals)) + 
  geom_point() + 
  geom_hline(yintercept = 0, color = "red") + 
  scale_color_viridis_c()


# add second variable 
less_simple_model <- lm(fatal_rate ~ beertax + unemp, 
                   data = Fatalities)
summary(less_simple_model)

# stargazer ####
# you can use the stargazer package to generate nice LATEX or HTML tables 
# you can export these - they'll generate the tables you're used to seeing
# in academic papers and such 
stargazer(simple_model, less_simple_model,
          type = "text",
          title = "Results")

# this is an increasingly popular table 
# and can save you a lot of time when you want to share results or 
# start writing papers 
# NOTE - stargazer doesn't default to using robust standard errors 
#
cov         <- vcovHC(less_simple_model, type = "HC1")
robust_se    <- sqrt(diag(cov))

# Stargazer output (with and without RSE)
stargazer(less_simple_model, less_simple_model, type = "text",
          se = list( NULL, robust_se),
          add.lines = list(c("Robust?", "No", "Yes")))

# Fixed Effects ####
# add fixed effects via factor variabe

model_FE_1 <- 
  lm(fatal_rate ~ beertax + unemp + state,
     data = Fatalities)
summary(model_FE_1)
# with categorical/factor variables - you have to be thoughtful 
# because of the full rank requirement, one category must be 
# excluded from the model (otherwise you cant run this code)
# for example - look what we have to do with year so it's not treated 
# like a numeric variable (this dataset actually has it saved as a factor)
model_FE_2 <- 
  lm(fatal_rate ~ beertax + unemp + state + factor(year),
     data = Fatalities)
summary(model_FE_2)

# note with factors that look like numbers, hard to convert back 
unique(Fatalities$year)
unique(as.numeric(Fatalities$year))
# instead -
unique(as.numeric(as.character(Fatalities$year)))

# now our output is getting pretty long, so lets use a different package 
# to get prettier output from summary()

# felm instead - like with all things in r, multiple ways to do things 

# we put the fixed effects variables after the "|" in this package
# you can also cluster standard errors with this package - which is nice! 
felm_example_1 <- 
  lfe::felm(fatal_rate ~ beertax + unemp |
              state + factor(year),
            data = Fatalities)
summary(felm_example_1)  

# felm formula structure: 
# dep_var ~ covariate | fixed effects | IV specification |cluster SE 

felm_example_2 <- 
  lfe::felm(fatal_rate ~ beertax + unemp |
              state + factor(year) | 0 | state,
            data = Fatalities)
summary(felm_example_2)  

# we  this package calculates ROBUST clustered SE, 
# there are other popular packages for fixed effects models
# fixest is one I hear people talk about 
# can't speak much to which package is best 
# always options! 

# add RD 
# what if we know about a policy change in 1985
# and we want to implement regression discontinuity design
Fatalities <- 
  Fatalities %>% 
  mutate(
    numeric_year = as.numeric(as.character(year)),
    threshold = 
           if_else(numeric_year > 1985,
                             1, 0))

rd_example_1 <- 
  lm(fatal_rate ~ beertax + unemp + threshold + 
       I(numeric_year - 1985) + 
       I(numeric_year - 1985):threshold,
            data = Fatalities)
summary(rd_example_1)  

rd_example_2 <- 
  lm(fatal_rate ~ beertax + unemp +
       I(numeric_year - 1985)*threshold,
     data = Fatalities)
summary(rd_example_2)  

rd_example_3 <- 
  # not really RD - threshold is the RD variable, this is an interaction example
  lm(fatal_rate ~ beertax + unemp +
       I(numeric_year - 1985):threshold,
     data = Fatalities)
summary(rd_example_3) 

# note difference of syntax for * vs : for interaction variables 
# * includes both the interaction variables independently + together 
# : gives just the interaction 
# examples 1 & 2 here are IDENTICAL 
# and this is a dummy example - don't interpret the results :) 

# note: there are packages for regression discontinuity design 
# 'RDD'  might have advantages over lm() 
# https://rpubs.com/phle/r_tutorial_regression_discontinuity_design

# Add 2SLS + tests 
# remember how we could get the predicted results from our models? 
# we can use that to do a 2 stage model like so: 

stage_1 <- 
  lm(beertax ~ mormon,
     data = Fatalities)
summary(stage_1)

stage_1_results <-
  Fatalities %>% 
  add_predictions(stage_1) 

stage_2 <-
  lm(fatal_rate ~ pred,
     data = stage_1_results)
summary(stage_2)

# but there's a better way! 
# standard errors for this approach are invalid 
# we'll use a function 'ivreg' instead, same syntax as stata
# this is from the AER package

better_IV <- 
  ivreg(fatal_rate ~ beertax | mormon,
        data = Fatalities)

# even more convenient: 
summary(better_IV, diagnostics = TRUE)
# 
# 
# probit & logit 
# use 
# glm(dep ~ var, data = data, family = binomial)
# glm stands for 'generalized linear model' 
# can also use glm() to fit Poisson regression w/ family = poisson 
# I'm going to make some fake data to use this package 
set.seed(123) 
# set your seed so when you re-run this code you get the SAME random numbers 
# lets get 2 lists of 500 numbers each 
# 1 list - random from normal distribution 
list_norm <- rnorm(500, mean = 200, sd = 20)
# 1 list - random from uniform distribution 
list_unif <- runif(500, min = 100, max = 250)
# now we'll put together the data frames for each 
# normal distributin will be type 1, uniform will be 0 
norm_df <- 
  data.frame(
    type = 1, 
    values = list_norm
  )

unif_df <- 
  data.frame(
    type = 0, 
    values = list_unif
  )

full_df <- 
  bind_rows(
    norm_df,
    unif_df
  )

# logit model - predict if value comes from norm or unif distribution
test_logit <- 
  glm(type ~ values, data = full_df, 
      family = binomial(link = "logit"))

summary(test_logit)

# probit model - 
test_probit <- 
  glm(type ~ values, data = full_df, 
      family = binomial(link = "probit"))

summary(test_probit)

# to finish up - lets do a little practice together: 
# get the predicted probabilities from both the logit & probit models 
# get the average differences between them
# make a relevant graph with the data 



# Resources: #### 
# https://www.econometrics-with-r.org/index.html
# http://www.urfie.net/read/index.html 
# # https://www.statlearning.com
# for 'machine learning' - more complex models with training datasets & all 
# look at the tidymodels package ecosystem 
# 


em 