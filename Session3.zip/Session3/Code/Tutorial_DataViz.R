# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 01/15/2023
# Last Modified: 03/11/2023

#Purpose of script : Tutorial: Data Visualization
# Like all my other workshops, this is in no way 
# an exhaustive course 
# its designed to show you the basic structure of graphing in ggplot 
# and how to customize some aesthetics
# I provide a list of resources at the end for your future reference! 

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
library(here)
library(tidyverse)
library(tigris)
library(plotly)
library(ggiraph)
library(patchwork)

# load data 
raw_data <- 
  read.csv(here("Data", "Tutorial_Data_Output.csv")) %>% 
  mutate(GEOID = str_pad(GEOID, 5, "left", "0"))

census_region_lookup <- 
  read.csv(here("Data", "Census_Regions_Divisions.csv"))

full_data <- 
  raw_data %>% 
  left_join(census_region_lookup, 
            by = c("State_Name" = "state")) %>% 
  drop_na()

# section 1: scatterplot #### 
# basic graph - defaults! 
full_data %>% 
  ggplot() + 
  geom_point(
    aes( 
      x = pct_below_pov_rate,
      y = Med_HH_Inc,
      size = County_Population, 
      color = County_Population
      # we can map almost any aesthetic to a variable
    )
  ) 
# note use of PLUS instead of %>%  when layering 
# arguments onto a ggplot

# example 

# all good graphs need titles and clear axis labels 
# if you remember nothing else, remember this
# even working in excel or powerpoint or whatever, LABELS 
full_data %>% 
  ggplot() + 
  geom_point(
    aes( 
      x = pct_below_pov_rate,
      y = Med_HH_Inc,
    )
  ) + 
  labs(
    title = "Median Household Income & Povery Status in US Counties",
    x = "Percentage of Population Below Federal Poverty Rate",
    y = "Median Household Income",
    caption = "American Community Survey, 2020"
  )
# there are a few different ways to do this - I like labs for simplicity 


# now lets fix those axis labels 
simple_graph <- 
  full_data %>% 
  ggplot() + 
  geom_point(
    aes( 
      x = pct_below_pov_rate,
      y = Med_HH_Inc
    )
  ) + 
  scale_y_continuous(
    breaks = c(0, 50000, 100000, 150000),
    labels = c("", "$50,000", "$100,000", "$150,000")
  ) + 
  scale_x_continuous(
    breaks = c(0, 0.2, 0.4, 0.6),
    labels = c("0", "20%", "40%", "60%")
  ) + 
  labs(
    title = "Median Household Income & Povery Status in US Counties",
    x = "Percentage of Population Below Federal Poverty Rate",
    y = "Median Household Income",
    caption = "American Community Survey, 2020"
  )

simple_graph

# you can totally stop here thats fine, but lets have a little fun 
# lets show where the different regions of the US show up on this graph

# aes is for mapping things to a VARIABLE
# if you just want the characteristic to be a static value
# it doesnt need to be in aes 
# so we could assign color = "red" outside of aes() 
# but color = census_region is different! 

color_by_region <- 
  full_data %>% 
  ggplot() + 
  geom_point(
    aes( 
      x = pct_below_pov_rate,
      y = Med_HH_Inc,
      color = census_region
    ),
   # color = "red"
  ) + 
  scale_y_continuous(
    breaks = c(0, 50000, 100000, 150000),
    labels = c("", "$50,000", "$100,000", "$150,000")
  ) + 
  scale_x_continuous(
    breaks = c(0, 0.2, 0.4, 0.6),
    labels = c("0", "20%", "40%", "60%")
  ) + 
  labs(
    title = "Median Household Income & Povery Status in US Counties",
    x = "Percentage of Population Below Federal Poverty Rate",
    y = "Median Household Income",
    caption = "American Community Survey, 2020",
    color = "Census Region"
  )

color_by_region

# well this is a little messy - can we split up these graphs somehow? 
# yes! 
color_by_region + 
  facet_wrap(facets = vars(census_region))
# these little graphs are called "facets"
# in this case the axis scales are the same in each facet
# it is possible to have 'free scales'
# you can specify in the facet_wrap/grid function :) 


# section 2: histogram & other distributions ####

full_data %>% 
  ggplot(aes(x = Med_HH_Inc)) + 
  geom_histogram() 

# lets specify a 'bin width' of say... $5,000
# and see differences by census region again 
# note use of 'fill' instead of 'color' here 
full_data %>% 
  ggplot( aes(x = Med_HH_Inc, 
              fill = census_region)) + 
  geom_histogram(
    binwidth = 5000
  ) 

summary(full_data$Med_HH_Inc)

# to understand the concept of a geom
# see how easy it is to do a boxplot instead? 
full_data %>% 
  ggplot( aes(x = Med_HH_Inc)) + 
  geom_boxplot() 

full_data %>% 
  ggplot( aes(x = Med_HH_Inc, 
              fill = census_region)) + 
  geom_boxplot() 

# ok back to our histogram to go crazy with the visuals 
# like before - we need to fix our labels!!! 
colorful_histogram <- 
  full_data %>% 
  ggplot( aes(x = Med_HH_Inc,
              fill = census_region)
          ) + 
  geom_histogram(
    binwidth = 5000
  ) + 
  scale_x_continuous(
    expand = c(0, 0), # removes that gap between axis & graph itself
    limits = c(0, 150000), # axis limits 
    breaks = c(0, 25000, 50000, 75000,
               100000, 125000, 150000), # where you want the ticks to be
    labels = c("", "$25,000", "$50,000","$75,000", # what the labels are 
               "$100,000", "$125,000",  "$150,000") # literally 
  ) + 
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 600),
    breaks = c(0, 200, 400, 600),
    labels = c("0", "200", "400", "600")
  ) + 
  labs( # there are other ways to do this - whatever works is fine! 
    title = "Distribution of Median Household Income of US Counties",
    y = "Number of Conties",
    x = "Median Household Income",
    caption = "American Community Survey, 2020",
    fill = "Census Region"
  )

colorful_histogram


# what bugs me? this general aesthetic 
# first - I'm gonna say we change the fill colors 

# we can define our own colors manually 
# via built in names in R 
colorful_histogram + 
  scale_fill_manual(
    values = c("red", "blue", "green", "yellow")
  ) 
# OR with HEX codes 
colorful_histogram + 
  scale_fill_manual(
    values = c("#4C212A", "#01172F", "#00635D", "#08A4BD")
  ) 
# OR we can just use a nice palette that someone else has come up with 
# viridis is a very popular one for both discrete & continuous scales
viridis_histogram <- 
  colorful_histogram + 
  scale_fill_viridis_d() # d for discrete
viridis_histogram

# what about adjusting the other aesthetics of the graph? 
# we can use some built in 'themes' in ggplot to see some options 


# good for getting rid of that grey background, keeping grid lines 
viridis_histogram +
  theme_bw()

# a nice classic look
viridis_histogram +
  theme_classic()

# for the minimalists 
viridis_histogram +
  theme_void()


# you can also define your own themes and get very detailed with it 
# for an example - the BBC has their own theme you can play with 
# https://bbc.github.io/rcookbook/

# lets build a simple little theme up ourselves
# for a histogram I think it's nice to work with the classic 
# theme as a base

# for an extreme example - 
# what if we want to be cool & have an all black background? 
viridis_histogram +
  theme(
    plot.background = element_rect(fill = "black")
    #element_rect - the background is a rectangle 
  )

# ok - what else do we need to do to make this WORK? 
# panel background should also be black (in this case - we set to transparent),
# and all text needs to be white 
viridis_histogram +
  theme(
    plot.background = element_rect(fill = "black"),
    panel.background = element_rect(fill = NA),
    legend.background = element_rect(fill = NA),
    # text elements use element_text, can also change the font, font size, etc.
    # within the theme 
    text = element_text(color = "white"),
    axis.text = element_text(color = "white")
  )

# ok what about these weird grid lines? I don't like them in most graphs 

viridis_histogram +
  theme(
    plot.background = element_rect(fill = "black"),
    panel.background = element_rect(fill = NA),
    legend.background = element_rect(fill = NA),
    text = element_text(color = "white"),
    axis.text = element_text(color = "white"),
    panel.grid = element_blank() 
    # this is useful when you want something to go away
  )

# wait but we still want axis lines 
good_histogram <- 
  viridis_histogram +
  theme(
    plot.background = element_rect(fill = "black"),
    panel.background = element_rect(fill = NA),
    legend.background = element_rect(fill = NA),
    text = element_text(color = "white"),
    axis.text = element_text(color = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "white")
  )

good_histogram

# lets save this 
# can also save jpg, png, other formats 
# version control still important for graphics
ggsave(
  filename = here("Output",
                  paste0("Good_Histogram_Name_", Sys.Date(), ".jpeg")),
  good_histogram
)
# can specify dimensions
#ggsave will tell you what it does in the console


# lets say thats done - you can adjust a lot of other things

# section 3 - MAPPING #### 
# what is a map? 
# how to get shapes associated with states and counties to make a map? 
# US census provides these shapefiles - you can go download them online 
# we'll pull them in with the tigris package 

# get county shapefile for North Carolina 

NC_Counties <- 
    counties(year = 2019, state = "NC",  
           cb = TRUE, class = "sf") 
# cb = level of detail for the lines of our borders 
# true would give us the most detailed version, we don't need that 
# class = "sf" gives us a shapefile, 

# join onto our full_data table by GEOID
# we'll use a left join here to implicitly filter to only NC counties 

full_map_data <- 
  NC_Counties %>% 
  left_join(full_data,
            by = "GEOID") 
# remember - we don't need to specify GEOID in the join
# but it makes for more legible codde 

# we're going to use ggplot + geom_sf, 
# there are a lot of other mapping packages out there
# but I like to stay in the ggplot ecosystem 
full_map_data %>% 
  ggplot() + 
  geom_sf(mapping = aes(fill = Med_HH_Inc))

# look! a map! 
# what's happening here? 
# the shapefile is providing the shapes of the counties 
# and in aggregate, we get the state of NC from all those together
# note that the x & y coordinates are lat/long
# so if you had the coordinates for a list of NC cities here, we can layer 
# lets just do some basic aesthetic improvements 
# void theme, clear title & labels, different color palette (viridis again)
nice_map <- 
  full_map_data %>% 
  ggplot() + 
  geom_sf(aes(fill = Med_HH_Inc),
                color = NA) + 
  #scale_fill_viridis_c() + # I find the gradient bar a little hard to read
  scale_fill_binned( # you can of course define bins
    type = "viridis", 
  labels = scales::label_comma()) + # scales package internal to ggplot, nicer labels 
  theme_void() + 
  labs(title = "North Carolina Median Household Income, 2020",
       fill = "")

nice_map

# lets save this 
ggsave(
  filename = here("Output",
                  paste0("NC_Med_Inc_Map_", Sys.Date(), ".jpeg")),
  nice_map
  )

# we could map the whole country using this same method
# but you always have to adjust for the location of Alaska & Hawaii 
# so it's too complicated for training purposes 


# displaying graphs next to eachother with patchwork 
nice_map / (simple_graph + good_histogram)
# note you'll need some finessing of labels to do this
# syntax of patchwork makes a lot of stuff implicit
# there are other ways to do this that give you more control 

# interactive capabilities of GGPLOT: 

# option 1 - ggplotly 
# it's this easy: 
ggplotly(nice_map)

?ggplotly()
# you can customize tooltips 
# you can implement these into shinyapps - R dashboards
# or you can export these as part of markdown documents 
# or embed them into webpages 

# option 2 - ggiraph 
# this is a little more complex 
# I'm going to link our original scatterplot to the map we made
# but the code looks a little different 
# 
simple_graph_interactive <- 
  full_data %>% 
  filter(State_Name == "North Carolina") %>% 
  ggplot( 
    aes( 
    x = pct_below_pov_rate,
    y = Med_HH_Inc,
    data_id = County_Name,
    tooltip = County_Name)
  ) + 
  geom_point_interactive(
    hover_nearest = TRUE
  ) + 
  scale_y_continuous(
    breaks = c(0, 30000, 50000, 80000,  100000),
    labels = c("", "$30,000", "$50,000", "$80,000","$100,000")
  ) + 
  scale_x_continuous(
    breaks = c(0, 0.1, 0.15, 0.2, 0.25, .3),
    labels = c("0", "10%" , "15%", "20%", "25%", "30%")
  ) + 
  labs(
    title = "Median Household Income & Povery Status in US Counties",
    x = "Percentage of Population Below Federal Poverty Rate",
    y = "Median Household Income",
    caption = "American Community Survey, 2020"
  )

simple_graph_interactive

girafe(
  print(simple_graph_interactive))

# and now the map 

nice_map_interactive <- 
  full_map_data %>% 
  ggplot() + 
  geom_sf_interactive(aes(fill = Med_HH_Inc,
                          data_id = County_Name,
                          tooltip = County_Name),
          color = NA
          ) + 
  #scale_fill_viridis_c() + # I find the gradient bar a little hard to read
  scale_fill_binned( # you can of course define bins
    type = "viridis", 
    labels = scales::label_comma()) + # scales package internal to ggplot, nicer labels 
  theme_void() + 
  labs(title = "North Carolina Median Household Income, 2020",
       fill = "")


girafe(
  print(nice_map_interactive))

# note that these two graphs we've made both have the same data_id
#
girafe(
  print(nice_map_interactive / simple_graph_interactive))

# you can set data_ids to be groups instead of individual ids 
# for example 

interactive_graph_see_states <- 
  full_data %>% 
  ggplot( 
    aes( 
      x = pct_below_pov_rate,
      y = Med_HH_Inc,
      data_id = State_Name,
      tooltip = paste0(County_Name, ",", State_Name)),
    alpha = 0.5
  ) + 
  geom_point_interactive(
    hover_nearest = TRUE
  ) + 
  scale_y_continuous(
    breaks = c(0, 30000, 50000, 80000,  100000),
    labels = c("", "$30,000", "$50,000", "$80,000","$100,000")
  ) + 
  scale_x_continuous(
    breaks = c(0, 0.1, 0.15, 0.2, 0.25, .3),
    labels = c("0", "10%" , "15%", "20%", "25%", "30%")
  ) + 
  labs(
    title = "Median Household Income & Povery Status in US Counties",
    x = "Percentage of Population Below Federal Poverty Rate",
    y = "Median Household Income",
    caption = "American Community Survey, 2020"
  )

girafe(print(interactive_graph_see_states))
# theres some layering issues here
# but we can adjust the opacity of our points! 

# RESOURCES: #### 
# General data visualization 
# https://r4ds.had.co.nz/data-visualisation.html
# https://guides.library.duke.edu/datavis/topten
# https://datavizproject.com/data-type/polar-area-chart/
# https://www.data-to-viz.com

# General ggplot reference & inspiration: 
# https://r-graph-gallery.com/index.html
# https://www.maths.usyd.edu.au/u/UG/SM/STAT3022/r/current/Misc/data-visualization-2.1.pdf
# http://r-statistics.co/Top50-Ggplot2-Visualizations-MasterList-R-Code.html

# Great GGPlot Extensions 
# https://rpkgs.datanovia.com/ggpubr/
# https://github.com/hafen/geofacet
# https://patchwork.data-imaginist.com
# http://davidgohel.github.io/ggiraph/
# https://plotly.com/ggplot2/

# Color palette generation 
# https://mycolor.space
# https://coolors.co
