# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 11/29/2022
# Last Modified: 

#Purpose of script : Tutorial: Bulk data download & import 
#

# Script Setup #### 
#clear environment 

rm(list = ls())
gc()

# libraries 
library(here)
library(tidyverse)

# Discuss difference between for loops & vectorizing over a function
# lets talk about for loops 
for(i in 1:10) {                                           
  x1 <- i^2                                       
  print(x1)                                                
}

# issues with for loops:  
# difficult to debug - hard to manipulate this code to just get one or two iterations
# if there's an issue with one iteration, it'll fail
# for loops can also be slower than the alternative 
# which is to turn the operation into a function, then vectorize over the list 

list <- c(1:10) 

example_function <- function(value) {value^2}

map_dbl(list, example_function)

#exact same thing - but we can debug with 
example_function(10)
# questions?  

# ok - time for a more complicated example 

#what are we doing? 
# downloading QCEW data from
# https://www.bls.gov/cew/additional-resources/open-data/
# CSV Data Slices 
# then importing and appending all data

STATE_FIPS_LIST <- 
  c("06000", # California
    "37000", # North Carolina
    "26000", # Michigan
    "01000" # Alabama
    )


YEARS <- seq(2015,2020)

# we have a list of years & states, but not a list of all combinations between 
all_combinations <- 
  expand.grid(
    list_years = YEARS,
    list_counties = STATE_FIPS_LIST
  )

# our data is available for download from links with a specific pattern 
# we define this function which takes the year & area and makes the URL for the file we want 
form_urls <-
  function(year, area_fips){
    paste0(
      "http://data.bls.gov/cew/data/api/", year, "/a/area/", area_fips, ".csv")
  }

# map2 passes both these vectors through our form URL function
# it does things in parallel, it doesn't have expand.grid built in
# map2_chr : takes 2 vectors as arguments for 1 function, and returns a character vector 
url_list <- 
  map2_chr(all_combinations$list_years, 
           all_combinations$list_counties,
           form_urls)


# what do we want our files to be named and where do we want them to go? 
# I've set up an empty folder to put them all in 
form_file_destination <- 
  function(county_fips, year){
    here("Data", "Downloaded_QCEW", paste0(county_fips, "_", year, ".csv"))
  }

file_destination_list <- 
  map2_chr(
    all_combinations$list_years, 
    all_combinations$list_counties,
    form_file_destination)

# download.file takes all the urls, downloads all the files, and puts them 
# in the specified destinations for file_destination_list
# again - map2 works in parallel, so the first url is downloaded to the first 
# destination file path w/ the appropriate name
map2(
     url_list,
     file_destination_list,
     download.file
   )


# now we want to load in all our files 
# we already have the list of these files 
# pass this list to read csv 
# suffix _dfr means output of this function will be a dataframe 
csv_data_all <- 
  map_dfr(
    file_destination_list,
    read.csv
  )
# equivalent to reading in each file individually 
# and then using bind_rows() to combine! 

# this is an easy example since the data files themselves already have 'year' and 'state' 
# variables for identifying their source, but this will not always be the case, so make sure you have everything you need
# from each file - or make sure you're adding in the appropriate indicators

# intuition: if you are about to write the same code more than 2-3 times
# then its time to write a function instead 
# think about what changes and what stays the same for each iteration
# functions are much easier to test than for loops! 