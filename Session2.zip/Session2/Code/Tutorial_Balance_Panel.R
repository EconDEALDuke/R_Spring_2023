# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 11/29/2022
# Last Modified: 

#Purpose of script : Tutorial: Balance unbalanced panel 
#

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
library(here)
library(tidyverse)

# load data 
raw_data <- 
  read.csv(here("Data", "unbalanced_panel.csv"))

# get list of states 
all_states <- unique(raw_data$state_name)

all_years <- seq(2000, 2022)

# generate data frame with all possible observations 
all_observations <- 
  expand.grid(
    year = all_years,
    state_name = all_states
  )

# which observations are missing? 
missing_obs <-
  anti_join(
    all_observations,
    raw_data
    ) %>% 
  mutate(data_exists = 0)

# balance panel by combining existing & missing obs 
full_panel <- 
  bind_rows(raw_data, missing_obs)

# fun alternative - filling in missing obs revealed by reshaping data 
wide_panel <- 
  raw_data %>%
  arrange(state_name) %>% 
  pivot_wider(
    id_cols = year,
    names_from = state_name,
    values_from = data_exists,
    values_fill = 0
  ) %>% 
  arrange(year)

# what if I want to reshape it back to long? 
long_panel <- 
  wide_panel %>% 
  pivot_longer(
    cols = c(2:52),
    names_to = "state_name",
    values_to = "data_exists"
  )

# I would recommend anti-joins to balance panels with more finesse, 
# there are a lot of other reasons you may want to reshape data


