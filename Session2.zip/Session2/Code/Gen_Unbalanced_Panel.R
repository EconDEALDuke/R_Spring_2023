# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 11/29/2022
# Last Modified: 

#Purpose of script : IGenerates data for DEAL tutorial 
#

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
library(here)
library(tidycensus)
library(tidyverse)


lookup <- 
  tidycensus::fips_codes %>% 
  filter(state_code < 60) %>% 
  mutate(FIPS = paste0(state_code, county_code)) 

unique_states <- unique(lookup$state_name)

unique_years <- seq(2000,2022)  

full_panel <- 
  expand.grid(
    year = unique_years,
    state_name = unique_states
  ) %>% 
  mutate(
    data_exists = 1
  )

# unbalance panel 
set.seed(26)
unbalanced_panel <-
  full_panel %>% 
  slice_sample(n = 900)

write.csv(
  unbalanced_panel,
  here("Data", "unbalanced_panel.csv"),
  row.names = FALSE)

