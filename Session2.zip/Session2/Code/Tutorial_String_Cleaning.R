# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 11/29/2022
# Last Modified: 

#Purpose of script : Tutorial: String Cleaning 
#

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
library(here)
library(tidycensus)
library(tidyverse)

# load data 
county_income <-
  read.csv(
    here("Data", "county_income.csv"),
    colClasses = c("character", "numeric") # define variable types, not required
  ) 

icu_beds <-
  read.csv(here("Data", "icu_beds.csv"),
           na.strings = "null") %>% #na.strings - because the .csv file has "null" where no data  
  janitor::clean_names() %>% # very useful function  
  mutate(icu_beds_per_person = icu_beds/total_population,
         icu_beds_per_10k = icu_beds/(total_population/10000),
         zero_beds = ifelse(icu_beds == 0, 1, 0))

# this is a very annoying data frame because there are no FIPS codes in the ICU beds data
# so we cant join it on to the county income data immediately, but we can fix this! 

view(fips_codes) #some packages like tidycensus have built in data tables that can come in handy! 

#to get fips codes for the icu beds data, we need to make the county name variables match EXACTLY 
# we want this to have 0 observations i.e. everything is matching 
test_fips_lookup <- 
  icu_beds %>% 
  anti_join(fips_codes, by = c("state" = "state_name",
                               "county" = "county"))
#not very good! gotta do some string parsing to make them match :) 

# First -  We want to shave off words like "County" and "Parish" from the fips_lookup 
pats <- c("County|Parish|Census Area|Borough|City and Borough") 

# "|" is the or operator in R - so this is looking for "County" OR "Parish" OR 
# the other patterns in the list 

# ok - lets clean up the County_Name variable 
fips_lookup_v1 <-
  fips_codes %>% 
  #trim the values in pats from the variable county 
  mutate(County_Name = str_trim(str_remove_all(county, pats), "both")) %>% 
  #replace instances of city with the uppercase City
  mutate(County_Name = str_replace_all(County_Name, "city", "City")) #

# lets use another anti join to see what impact that made
test_fips_lookup <- 
  icu_beds %>% 
  anti_join(fips_lookup_v1, by = c("state" = "state_name",
                                "county" = "County_Name"))
# this actually gets us pretty close to matching - with a few exceptions 
# since there are only a few, we'll just use
#case_when() to replace specific values 

fips_lookup <- 
  fips_lookup_v1 %>% 
  mutate(County_Name = case_when(
    County_Name == "District of Columbia" ~ "The District",
    County_Name == "La Salle" & 
      state == "LA" ~ "LaSalle",
    County_Name == "Anchorage Municipality" ~ "Anchorage",
    County_Name == "Kodiak Island" ~ "Kodiak Island Borough",
    County_Name == "North Slope"  ~"North Slope Borough",
    County_Name == "Northwest Arctic"  ~ "Northwest Arctic Borough",
    County_Name == "Petersburg"  ~ "Petersburg Borough",
    County_Name == "Sitka"  ~ "Sitka Borough",
    County_Name == "Southeast Fairbanks"  ~ "Southeast Fairbanks ",
    County_Name == "Valdez-Cordova"  ~ "Valdez-Cordova ",
    County_Name == "Wrangell"  ~ "Wrangell City and Borough",
    County_Name == "Yakutat"  ~ "Yakutat City and Borough",
    TRUE ~ County_Name 
    # case when evaluates arguments sequentiallyy 
    # so if one of the arguments comes back as true, it adjusts the value of the variable
    # the last line means that if none of the previous arguments are true, the County_Name is unchanged
    # luckily this is a relativelly small table, this kind of manual work would be very 
    # time consuming with anything bigger
      )) %>% 
  mutate(FIPS = paste0(state_code, county_code)) %>% #this creates the 5 digit geoid we know and love
  select(state_name,
         County_Name,
         FIPS) #and we dont care about anything but these 3 variables anymore!

# I use anti-joins to figure out where things don't match up perfectly
# When writing this - I went back and forth between the anti-join & 
# the above line 
test_fips_lookup <- 
  icu_beds %>% 
  anti_join(fips_lookup, by = c("state" = "state_name",
                                "county" = "County_Name"))

# join data! 

wide_data <- 
  icu_beds %>% 
  # first join fips codes onto ICU beds data 
  left_join(fips_lookup, by = c("state" = "state_name",
                                "county" = "County_Name")) %>% 
  # then join income data on using the FIPS code column in each 
  left_join(county_income, 
            by = c("FIPS" = "GEOID"))

# celebrate! 

