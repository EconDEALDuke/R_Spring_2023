############
# Primary Author:Jenna Goldberg
# Last Editor: 
# Creation date: 12/16/2020
# Last Modified: 04/15/2023

# Depends on:

# Change Log:
# 04/15/23 - added comments for workshop 

#clear environment 
rm(list = ls())
gc()

#load libraries 
library(tidyverse)
library(tigris)
library(shiny)
library(shinythemes)
library(plotly)

#input_state <- "Tennessee"

# list of states from TIGRIS 
state_options <- unique(fips_codes$state_name)

# define UI 
ui <- fluidPage(
  # see all possible themes here: https://rstudio.github.io/shinythemes/
  theme = shinytheme("sandstone"),
  
  # extremely cool & creative title 
  titlePanel("Cool & Creative County Data Exploration Tool"),

    sidebarPanel(
      # inputs go here
      selectizeInput("input_state", # what we'll call this input in the server 
                     "State", # label of box in the UI 
                     choices = state_options,  # our vector from earlier 
                     selected = NULL, # default 
                     multiple = TRUE), 
      # selctize vs selectInput - you can select multiple options
      # to allow multiple states 

    fileInput(inputId = "filedata",
              label = "Upload data. Choose csv file",
              accept = c(".csv")), 
    # we could expand this 
    # to work for more data types 
    # but we'd have to expand things in the server 
    
    textInput(inputId = "geoid_column", "Name of GEOID Column",
              value = "",
              width = NULL,
              placeholder = NULL),
    
    textInput(inputId = "value_column", "Name of Value to Visualize",
              value = "",
              width = NULL,
              placeholder = NULL)
  ),
    
    mainPanel(
      # outputs here
      plotlyOutput("map"), # for a ggplotly object
      
      verbatimTextOutput("summary"), # for literal console output
    
      plotOutput("hist") # for a static graph 
    ) 
)

server <- function(input, output) {
  
  # first - what is our data? 
  # user data takes the file from the input upload option
  user_data <- reactive({
    
    # add in error codes! we'll dectivate this in a minute to see 
    # why they're so nice 
     validate(
       need(input$filedata != "", "Please import data"),
       need(input$geoid_column != "", "Please identify GEOID column"),
       need(input$value_column != "", "Please identify value column")
     )
    # currently only accepts .csv files 
    read.csv(input$filedata$datapath) %>% 
      select(input$geoid_column, # UI tells us what these columns are 
             input$value_column) %>% 
      rename( 
        GEOID = 1, 
        Value = 2
      ) %>% 
      # do a little data cleaning - csv files often drop the leading 0s
      # when it doesnt realize FIPS codes are strings not numbers
      # i.e. "01001" becomes 1001
      mutate(GEOID = str_pad(GEOID, 5, "left", "0"))
    })
  
  # if we wanted to accept multiple file types - we could code in conditions
  # think : if filedata$datapath ends in xlsx instead of csv use read_xl 
  # insetad of read.csv
  
  # get county shapefiles for the selected state(s)
  # county
  county_data <- reactive({ 
    # error code -
    # we'll deactivate this in a minute to see what its doing
     validate(
       need(input$input_state != "", "Please select a state")
    # )
    # 
    # luckily counties() takes vectors! 
    county_sf <- 
      counties(input$input_state,
               class = "sf",
               cb = TRUE) %>% 
      # add user input data to our shapefile so we can make cute maps 
      inner_join(user_data(), by = "GEOID") %>%
      # for our tooltip - \n creates a new line in a string
      # note that I'm using paste0, but making sure there are spaces between 
      # each part of the text we want 
       mutate(`County Details` = paste0(
                                     "\n Name: ", NAME, " County "))
  })  
  
  output$map <-
    renderPlotly({
    ggplotly(
         ggplot() + 
           geom_sf(data = county_data(),
                         color = "black", # outline color 
                        lwd = 0.5,
                          aes(label = `County Details`, # for our tooltip! 
                              fill = Value)) +
          theme_void() + # I like theme_void for maps
        scale_fill_viridis_c()) %>% # you can always use other palettes 
        # hover over the fill (not the outline) of the counties
        # don't need to worry about this if you're 
        # making a ggplotly object from a scatterplot! 
        style(hoveron = "fill")
  })
  
  # add summary statistics for our data subset 
  output$summary <- renderPrint({
    dataset <- county_data()
    summary(dataset$Value, na.rm = T)
  })
  
  # and we'll add another graph just for fun 
  output$hist <- renderPlot({
    ggplot(county_data()) +
      geom_histogram(
        aes(Value)) + 
      theme_classic() + 
      ylab("Count of Counties")
  })
  }

# run the app! 
shinyApp(ui = ui, server = server)

# try importing our Tutorial_Output_Data
# tell the app to use the columns GEOID & Med_HH_Inc
# select whatever state you want 

# if you have another county level dataset handy - feel free to test that 
# just needs to have FIPS codes 

# think about how you would actually DEVELOP this 
# I went through one or two example states & data files 
# before I turned this into an app 
# and thought carefully about what would need to be generalized
# to make this work for any csv flie 
# things like renaming columns based on user input

# unlike many other R scripts - where things are 
# written more or less in consecutively 
# in the 'import -> clean -> analyze' pipeline 

# the order in which things appear in this script 
# is not the order in which things were written!

