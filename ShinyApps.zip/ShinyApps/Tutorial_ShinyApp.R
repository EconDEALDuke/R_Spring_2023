# Header #####
# Primary Author: Jenna Goldberg 
# Last Editor: 
# Creation date: 11/29/2022
# Last Modified: 

#Purpose of script : Tutorial: Intro to ShinyApps 
#
# Inspiration: 
# https://shiny.rstudio.com/gallery/uber-rider.html
# https://shiny.rstudio.com/gallery/covid19-tracker.html
# https://shiny.rstudio.com/gallery/biodiversity-national-parks.html
# https://shiny.rstudio.com/gallery/freedom-press-index.html
# Code for all of these is public
# I'm going to show you guys the BASICS 
# I am not an expert Shiny Dev - I've made a few simple things
# Here's an app I made a few years ago: 
# https://jenna-goldberg.shinyapps.io/mapmakingapp/

# Script Setup #### 
#clear environment 
rm(list = ls())
gc()

# libraries 
# make sure to install whichever packages you don't already have! 
library(here)
library(tidyverse)
library(shiny)
library(DT)
library(plotly)
library(bslib)
library(shinythemes)
library(thematic)

# 
# load data ####
raw_data <- 
  read.csv(here("Data", "Tutorial_Data_Output.csv")) %>% 
  mutate(GEOID = str_pad(GEOID, 5, "left", "0"))

census_region_lookup <- 
  read.csv(here("Data", "Census_Regions_Divisions.csv"))

full_data <- 
  raw_data %>% 
  left_join(census_region_lookup, 
            by = c("State_Name" = "state")) %>% 
  drop_na()

# basic shinyapp #### 
# 2 parts: 
# ui & server 
# server is all the guts of the app, UI is how it'll appear & layout

minimal_ui <- fluidPage( # this is a layout function 
  "Hello, world!",
  textInput("name", "What's your name?"),
  sliderInput("rng", "Range", value = c(10, 20), min = 0, max = 100)
  )

blank_server <- function(input, output, session) {
  # back end logic
  }

shinyApp(minimal_ui, blank_server)

# in the UI - the input options are called 'widgets' 
# see more options here: https://shiny.rstudio.com/gallery/widget-gallery.html

# close the app before running anything else! 

# ui structure example 
ui_example <- 
  fluidPage(
    titlePanel("My Shiny App"),
    sidebarLayout(
      sidebarPanel(),
      mainPanel( # each comma indicates a new row 
        h1("First level title"),
        h2("Second level title"),
        h3("Third level title"),
        h4("Fourth level title"),
        h5("Fifth level title"),
        h6("Sixth level title"),
        "Normal Text"
      )
    )
  )

shinyApp(ui_example, blank_server)
# more examples: 
# https://shiny.rstudio.com/tutorial/written-tutorial/lesson2/ 
# https://shiny.rstudio.com/gallery/shiny-theme-selector.html
# you can include HTML 
# https://shiny.rstudio.com/gallery/including-html-text-and-markdown-files.html
# you can make the UI depend on user inputs 
# https://shiny.rstudio.com/gallery/dynamic-ui.html

# server doesn't interact with UI in any way - this is just an empty facade 
# lets do something simple to start 
# make a shiny app for viewing the full data table 

#in the server: we define an output object called 'mytable'
# can say where we want it in the UI 

# in the UI - say we want an output to be rendered
simple_table_ui <- 
  fluidPage( # this is a layout function 
    titlePanel("Data Exploration App"),
    dataTableOutput("mytable")
  )
# in the server - render the table as a 'DataTable' interactive object
simple_table_server <- function(input, output) {
  output$mytable <- renderDataTable({full_data})
}

shinyApp(simple_table_ui, simple_table_server)

# again - pretty simple, 
# what if we want to have some more back and forth between the UI & the server? 
# the UI stays exactly the same except for the addition of user input 

filter_table_ui <- 
  fluidPage(  
    titlePanel("Data Exploration App"),
    sidebarLayout( # more complicated UI setup 
      sidebarPanel( # ADDING A SIDEBAR 
        # input will be called 'region' that we can reference in UI
        # will have a drop down menu with all the census regions or 'all'
        selectInput("region",
                    "Region:",
                    c("All",
                      unique(full_data$census_region))),
  
        sliderInput("inc_rng", "Income Range",
                    value = c(0, 150000), #DEFAULT RANGE - select all 
                    min = 0, 
                    max = 150000) 
      ), # CLOSE SIDEBAR PANEL 
      mainPanel(
        dataTableOutput("mytable")) # we want our table to go here! 
    )
  )

# in the server - render the table as a 'DataTable' interactive object
filter_table_server <- function(input, output) {
   
  filter_table <- 
    reactive({ 
      data <- full_data %>% 
        filter(Med_HH_Inc > input$inc_rng[1] &  # access 1st number in range 
                 Med_HH_Inc < input$inc_rng[2])
      if (input$region != "All") {
         data <- data %>%  #further filtering if needed 
          filter( census_region == input$region)
      }
      data # data as reactive object saved as 'filter_table' 
      })
  
  
   output$mytable <- renderDataTable({
     datatable(filter_table())})
}
   # note that filter_table wont work, filter_table() is a REACTIVE OBJECT
    # like a function! 
shinyApp(filter_table_ui, filter_table_server)
# great! 

# now what if we want to add onto this? 
# we'll add another tab with a  reactive, interactive graph
# that receives the same inputs as the table 
# we're going to borrow the same ggplot code from my previous session 

multitab_ui <- 
  fluidPage(  
    titlePanel("Data Exploration App"),
    sidebarLayout( # more complicated UI setup 
      sidebarPanel( # ADDING A SIDEBAR 

        # select input - gives drop down menu 
        selectInput("region", # label for us in the server 
                    "Region:", # label for the text box in the UI
                    # will have options for all the census regions or 'all'
                    c("All",
                      unique(full_data$census_region))),
        
        sliderInput("inc_rng", "Income Range",
                    value = c(0, 150000), #DEFAULT RANGE - select all 
                    min = 0, 
                    max = 150000) 
      ), # CLOSE SIDEBAR PANEL 
      mainPanel(
        tabsetPanel(
          # table in one tab  
          tabPanel("Table", dataTableOutput("mytable")),
           # graph in another 
          tabPanel("Scatterplot", plotOutput("reactive_scatterplot"))
    ))
    )
  )

multioutput_server <- function(input, output) {
      
      filter_table <- 
        reactive({ 
          # first filter to income range selected
          data <- full_data %>% 
            # reminder that R indexes start with 1, not 0 like Python 
            filter(Med_HH_Inc > input$inc_rng[1] &  # access 1st number in range 
                     Med_HH_Inc < input$inc_rng[2])
          # then - if an indiv region is selected, 
          # filter futher 
          if (input$region != "All") {
            data <- data %>%  
              filter(census_region == input$region)
            # selectInput only allows a single option to be chosen
            # we could do multiple options with selectizeInput in the UI
            # input$region would then return a LIST 
            # and then we'd change this filter to 'census_region %in% input$region'
          }
          data # data as the reactive object saved as 'filter_table' 
        })
      
      output$mytable <- renderDataTable({
        datatable(filter_table())})
      
      output$reactive_scatterplot <- renderPlot({
        filter_table() %>% 
          ggplot() + 
          geom_point(
            aes( 
              x = pct_below_pov_rate,
              y = Med_HH_Inc
              )
          ) + 
          labs(
            title = "Median Household Income & Poverty Status in US Counties",
            x = "Percentage of Population Below Federal Poverty Rate",
            y = "Median Household Income",
            caption = "American Community Survey, 2020"
          ) + 
          # using scales package instead of manually defining labels
          # that way when we filter data - labels are still nicely formatted
          scale_y_continuous(
            labels = scales::dollar_format()
          ) + 
          scale_x_continuous(
            labels = scales::percent_format()
          )
        })
}

shinyApp(multitab_ui, multioutput_server)


# lets do this as a ggplotly interactive object instead 
# very easy! 
# we have to do the following: 
# in the server: 
#   add ggplotly() to the graph
#   change to renderPlotly
# in the UI: change to 'plotlyOutput' 
# also adding color to the plot for later reasons... 

multitab_ui <- 
  fluidPage(  
    titlePanel("Data Exploration App"),
    sidebarLayout( # more complicated UI setup 
      sidebarPanel( # ADDING A SIDEBAR 
        # input will be called 'region' that we can reference in UI
        # will have a drop down menu with all the census regions or 'all'
        selectInput("region",
                    "Region:",
                    c("All",
                      unique(full_data$census_region))),
        
        sliderInput("inc_rng", "Income Range",
                    value = c(0, 150000), #DEFAULT RANGE - select all 
                    min = 0, 
                    max = 150000) 
      ), # CLOSE SIDEBAR PANEL 
      mainPanel(
        tabsetPanel(
          # table in one tab  
          tabPanel("Table", dataTableOutput("mytable")),
          # graph in another 
          tabPanel("Scatterplot", plotlyOutput("reactive_scatterplot"))
        ))
    )
  )

multioutput_server <- function(input, output) {
  
  filter_table <- 
    reactive({ 
      data <- full_data %>% 
        filter(Med_HH_Inc > input$inc_rng[1] &  # access 1st number in range 
                 Med_HH_Inc < input$inc_rng[2])
      if (input$region != "All") {
        data <- data %>%  #further filtering if needed 
          filter( census_region == input$region)
      }
      data # data as reactive object saved as 'filter_table' 
    })
  
  
  output$mytable <- renderDataTable({
    datatable(filter_table())})
  
  output$reactive_scatterplot <- renderPlotly({
    ggplotly(
    filter_table() %>% 
      ggplot() + 
      geom_point(
        aes( 
          x = pct_below_pov_rate,
          y = Med_HH_Inc,
          # adding this so we can pay with color later
          color = census_region 
        )
      ) + 
      labs(
        title = "Median Household Income & Poverty Status in US Counties",
        x = "Percentage of Population Below Federal Poverty Rate",
        y = "Median Household Income",
        caption = "American Community Survey, 2020"
      ) + 
      # using scales package instead of manually defining labels
      # that way when we filter data - labels are still nicely formatted
      scale_y_continuous(
        labels = scales::dollar_format()
      ) + 
      scale_x_continuous(
        labels = scales::percent_format()
      ))
  })
}

shinyApp(multitab_ui, multioutput_server)



first_bs_theme <- bs_theme(
  version = 5 # most recent default 
)
bs_theme_preview(theme = first_bs_theme, with_themer = TRUE)

theme_ui <- 
  fluidPage(  
    # lets play with themes 
    # first - shinythemes package 
    #theme = shinytheme("superhero"),
    #shinythemes::themeSelector(),
    # then - bootstrap themes 
   theme =  bs_theme(version = 4, bootswatch = "minty"),
    titlePanel("Data Exploration App"),
    sidebarLayout( 
      sidebarPanel( 
        selectInput("region",
                    "Region:",
                    c("All",
                      unique(full_data$census_region))),
        
        sliderInput("inc_rng", "Income Range",
                    value = c(0, 150000), 
                    min = 0, 
                    max = 150000) 
      ),
      mainPanel(
        tabsetPanel(
          tabPanel("Table", dataTableOutput("mytable")),
          tabPanel("Scatterplot", plotlyOutput("reactive_scatterplot"))
        ))
    )
  )

save_app <- shinyApp(theme_ui, multioutput_server)

# interactive bs_themer 
run_with_themer(save_app)
# w/ a bs_theme object active 
# note that the code for the theme you play with is returned in the console! 
# fun! 

# but note that the ggplot theme isn't being updated 
# nbd - we can change that 
# using the 'thematic' package 
thematic::thematic_shiny() 
# so graphs inherit theme characteristics
# but note COLORS dont really change based on theme 
# will still need to do SOME work 
run_with_themer(save_app)

# 

# how to deploy a shinyapp: https://shiny.rstudio.com/deploy/
# free & easy: shinyapps.io  

# need to pay to get more 'active apps' (free is up to 5)
# and 'active hours' for all apps (free - 25 hours)
# instructions are online - i've done this literally once
# so my info won't deviate from what's there in any way 

# othr options: 
# less easy: shiny server to
# deploy on your own web server 
# or use Posit's RStudio Connect 

